require("shuffle");
require("shuffle.mapping");
require("shuffle.settings");
require("shuffle.colors");
require("shuffle.treesitter");
